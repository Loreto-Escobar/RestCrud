package com.edutecno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonitorDeOrdenesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MonitorDeOrdenesApplication.class, args);
//		AnnotationConfigApplicationContext acac = new AnnotationConfigApplicationContext(AppConfig.class);
//		IServicioOrder servOrder = acac.getBean(IServicioOrder.class);
//		System.out.println(servOrder.listar("Shipped", "Blauer See Auto, Co.", Date.valueOf("2003-01-01"), Date.valueOf("2003-12-31")).getMensaje());
	}

}
