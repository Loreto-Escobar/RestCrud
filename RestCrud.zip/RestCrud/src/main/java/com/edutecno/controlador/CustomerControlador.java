package com.edutecno.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.edutecno.modelo.Customer;
import com.edutecno.servicio.IServicioCustomer;

@Controller
@RequestMapping("/clientes")
public class CustomerControlador {
	
	@Autowired
	IServicioCustomer servCliente;

	@ResponseBody @GetMapping("/buscarId")
	public Customer buscarPorCodigo(@RequestParam(required = false) Integer customerNumber) {
		Customer cliente = servCliente.buscarPorCodigo(customerNumber).getClientes().get(0);
		return cliente;
	}
	
	
	@GetMapping
	public List<Customer> listar(){
		
		List<Customer> clientes = servCliente.listar().getClientes();
		return clientes;
	}
}
