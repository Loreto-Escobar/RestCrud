package com.edutecno.controlador;

import java.sql.Date;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.edutecno.modelo.Customer;
import com.edutecno.servicio.IServicioCustomer;
import com.edutecno.servicio.IServicioOrder;
import com.edutecno.vo.OrderVO;

@Controller
@RequestMapping("/ordenes")
public class OrderControlador {
	
	@Autowired
	IServicioOrder servOrden;
	
	@Autowired
	IServicioCustomer servCliente;
	
	@GetMapping("/listar")
	public ModelAndView listar(
			@RequestParam(required = false) String estado,
			@RequestParam(required = false) String cliente,
			@RequestParam(required = false) Date fechaDesde,
			@RequestParam(required = false) Date fechaHasta
		) {
		ModelAndView mav = new ModelAndView("listarOrdenes");
		List<Customer> clientes = servCliente.listar().getClientes();
		OrderVO orderVo = servOrden.listar(
				estado, 
				cliente, 
				fechaDesde, //(fechaDesde==null||fechaDesde=="")?null:Date.valueOf(fechaDesde),
				fechaHasta  //(fechaHasta==null||fechaHasta=="")?null:Date.valueOf(fechaHasta)
			);
		List<Customer> clientesOrdenados = clientes.stream().sorted(Comparator.comparing(Customer::getCustomerName)).collect(Collectors.toList());
		mav.addObject("clientes", clientesOrdenados);
		mav.addObject("ordenes", orderVo.getOrdenes());
		mav.addObject("mensaje", orderVo.getMensaje());
		return mav;
	}
	
}
