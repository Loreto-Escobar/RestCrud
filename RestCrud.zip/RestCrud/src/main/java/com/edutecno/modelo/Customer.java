package com.edutecno.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "customers")
public class Customer {

	@Id
	@Column(name = "customernumber")
	private Integer customerNumber;
	@Column(name = "customername")
	private String customerName;
	@Column(name = "contactlastname")
	private String contactLastName;
	@Column(name = "contactfirstname")
	private String contactFirstName;
	private String phone;
	@Column(name = "addressline1")
	private String addressLine1;
	@Column(name = "addressline2")
	private String addressLine2;
	private String city;
	private String state;
	@Column(name = "postalcode")
	private String postalCode;
	private String country;
	@Column(name = "salesrepemployeenumber")
	private Integer salesRepEmployeeNumber;
	@Column(name = "creditlimit")
	private Double creditLimit;
	
	@OneToMany(mappedBy = "customer", fetch = FetchType.EAGER)
	private List<Order> ordenes;

}