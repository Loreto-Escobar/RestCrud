package com.edutecno.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edutecno.modelo.Customer;

public interface CustomerRepositorio extends JpaRepository<Customer, Integer>{

}
