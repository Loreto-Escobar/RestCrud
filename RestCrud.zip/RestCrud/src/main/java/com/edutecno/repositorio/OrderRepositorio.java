package com.edutecno.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edutecno.modelo.Order;

public interface OrderRepositorio extends JpaRepository<Order, Integer>{

}
