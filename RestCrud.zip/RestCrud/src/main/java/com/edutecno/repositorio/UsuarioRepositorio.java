package com.edutecno.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edutecno.modelo.Usuario;

public interface UsuarioRepositorio extends JpaRepository<Usuario, String>{

}
