package com.edutecno.servicio;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edutecno.modelo.Customer;
import com.edutecno.repositorio.CustomerRepositorio;
import com.edutecno.vo.CustomerVO;

@Service
public class CustomerServicio implements IServicioCustomer{
	
	private static final Logger logger = LoggerFactory.getLogger(CustomerServicio.class);
	
	@Autowired
	private CustomerRepositorio customerRepo;
	
	private CustomerVO customerVo;

	@Override
	public CustomerVO listar() {
		// TODO Auto-generated method stub
		customerVo = new CustomerVO(new ArrayList<Customer>(), "Ha ocurrido un error", "101");
		try {
			customerVo.setClientes(customerRepo.findAll());
			customerVo.setMensaje(String.format("Se encontraron %d clientes", customerVo.getClientes().size()));
			customerVo.setCodigo("0");
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("CustomerServicio: listar ", e);
		}
		return customerVo;
	}

	@Override
	public CustomerVO buscarPorCodigo(Integer codigoCliente) {
		// TODO Auto-generated method stub
		customerVo = new CustomerVO(new ArrayList<Customer>(), "Ha ocurrido un error", "102");
		try {
			customerVo.getClientes().add(customerRepo.findById(codigoCliente).get());
			customerVo.setMensaje(String.format("Se encontró el cliente %s", customerVo.getClientes().get(0).getCustomerName()));
			customerVo.setCodigo("0");
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("CustomerServicio: buscarPorCodigo ", e);
		}
		return customerVo;
	}
	
	

}
