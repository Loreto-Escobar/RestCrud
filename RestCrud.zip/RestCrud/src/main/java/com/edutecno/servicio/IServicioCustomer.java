package com.edutecno.servicio;

import com.edutecno.vo.CustomerVO;

public interface IServicioCustomer  {

	public CustomerVO listar();
	public CustomerVO buscarPorCodigo(Integer codigoCliente);
	
}
