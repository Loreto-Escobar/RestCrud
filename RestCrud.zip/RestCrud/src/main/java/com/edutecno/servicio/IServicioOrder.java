package com.edutecno.servicio;

import java.sql.Date;

import com.edutecno.vo.OrderVO;

public interface IServicioOrder {

	public OrderVO listar(String estado, String cliente, Date fechaDesde, Date fechaHasta);
	
}
