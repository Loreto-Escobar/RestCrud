package com.edutecno.servicio;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edutecno.modelo.Order;
import com.edutecno.repositorio.OrderRepositorio;
import com.edutecno.vo.OrderVO;

@Service
public class OrderServicio implements IServicioOrder{
	
	private static final Logger logger = LoggerFactory.getLogger(OrderServicio.class);

	@Autowired
	private OrderRepositorio orderRepo;
	
	private OrderVO orderVo;
	
	@Override
	public OrderVO listar(String estado, String cliente, Date fechaDesde, Date fechaHasta) {
		// TODO Auto-generated method stub
		orderVo = new OrderVO(new ArrayList<Order>(), "ha ocurrido un error", "102");
		try {
			List<Order> ordenes = orderRepo.findAll();
			List<Predicate<Order>> predicados = new ArrayList<Predicate<Order>>();
			if(estado != null && !estado.equals("")) {
				predicados.add(orden -> orden.getStatus().equals(estado));
			}
			if(cliente != null && !cliente.equals("")) {
				predicados.add(orden -> orden.getCustomer().getCustomerName().equals(cliente));
			}
			if(fechaDesde != null) {
				predicados.add(orden -> orden.getOrderDate().after(fechaDesde));
			}
			if(fechaHasta != null) {
				predicados.add(orden -> orden.getOrderDate().before(fechaHasta));
			}
			if(predicados.size() != 0) {
				Predicate<Order> resultadoFinal = predicados.get(0);
				for(int i = 1 ; i < predicados.size() ; i++) {
					resultadoFinal = resultadoFinal.and(predicados.get(i));
				}
				List<Order> ordenesFiltradas = ordenes.stream()
						.filter(resultadoFinal)
						.collect(Collectors.toList());
				orderVo.setOrdenes(ordenesFiltradas);
				orderVo.setMensaje(String.format("Las ordenes entregadas son %d", ordenesFiltradas.size()));
			}else {
				orderVo.setOrdenes(ordenes);
				orderVo.setMensaje(String.format("Las ordenes entregadas son %d", ordenes.size()));
			}
			orderVo.setCodigo("0");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("OrderServicio: listar ", e);
		}
		return orderVo;
	}

}
