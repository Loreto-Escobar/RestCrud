package com.edutecno.vo;

import java.util.List;

import com.edutecno.modelo.Customer;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class CustomerVO {
	
	private List<Customer> clientes;
	private String mensaje;
	private String codigo;

}
