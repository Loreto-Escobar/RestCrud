package com.edutecno.vo;

import java.util.List;

import com.edutecno.modelo.Order;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class OrderVO {

	private List<Order> ordenes;
	private String mensaje;
	private String codigo;
	
}
